# Deployment Instructions

## Quick Deploy

1. Upload files to server:
   ```bash
   scp -r usha-deploy/* user@your-server:/opt/usha/
   ```

2. SSH into server and run:
   ```bash
   cd /opt/usha/server
   npm install --production
   cp env.production.template .env
   nano .env  # Edit with your database password and settings
   ```

3. Configure Nginx (see nginx-screenshare.conf)

4. Start server:
   ```bash
   pm2 start dist/index.js --name usha-server
   pm2 save
   ```

5. Set up SSL:
   ```bash
   sudo certbot --nginx -d screenshare.transparentinsurance.net --email linkpellow@transparentinsurance.net --agree-tos --non-interactive
   ```

6. Reload Nginx:
   ```bash
   sudo nginx -t
   sudo systemctl reload nginx
   ```
